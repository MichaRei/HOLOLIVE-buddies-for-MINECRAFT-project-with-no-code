// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17+ for Yarn
// Paste this class into your mod and generate all required imports

package com.example.mod;
   
public class Jailbird - FABRIC extends EntityModel<Entity> {
	private final ModelPart jailbird;
	private final ModelPart body;
	private final ModelPart body2;
	private final ModelPart tail;
	private final ModelPart wings;
	private final ModelPart wingleft;
	private final ModelPart wingright;
	private final ModelPart feet;
	private final ModelPart footleft;
	private final ModelPart footright;
	private final ModelPart float;
	private final ModelPart submarine;
	private final ModelPart propulseA;
	private final ModelPart propulseur;
	private final ModelPart jetpack;
	private final ModelPart fireB;
	private final ModelPart fireA;
	public Jailbird - FABRIC(ModelPart root) {
		this.jailbird = root.getChild("jailbird");
		this.body = root.getChild("body");
		this.body2 = root.getChild("body2");
		this.tail = root.getChild("tail");
		this.wings = root.getChild("wings");
		this.wingleft = root.getChild("wingleft");
		this.wingright = root.getChild("wingright");
		this.feet = root.getChild("feet");
		this.footleft = root.getChild("footleft");
		this.footright = root.getChild("footright");
		this.float = root.getChild("float");
		this.submarine = root.getChild("submarine");
		this.propulseA = root.getChild("propulseA");
		this.propulseur = root.getChild("propulseur");
		this.jetpack = root.getChild("jetpack");
		this.fireB = root.getChild("fireB");
		this.fireA = root.getChild("fireA");
	}
	public static TexturedModelData getTexturedModelData() {
		ModelData modelData = new ModelData();
		ModelPartData modelPartData = modelData.getRoot();
		ModelPartData jailbird = modelPartData.addChild("jailbird", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 19.0F, 0.0F));

		ModelPartData body = jailbird.addChild("body", ModelPartBuilder.create(), ModelTransform.of(0.0F, 3.0F, 3.0F, 0.0F, 3.1416F, 0.0F));

		ModelPartData body2 = body.addChild("body2", ModelPartBuilder.create().uv(0, 2).cuboid(2.0F, -6.0F, -2.0F, 1.0F, 1.0F, 1.0F, new Dilation(0.0F))
		.uv(0, 4).cuboid(-3.0F, -6.0F, -2.0F, 1.0F, 1.0F, 1.0F, new Dilation(0.0F))
		.uv(20, 21).cuboid(-3.0F, -5.0F, -6.0F, 6.0F, 6.0F, 6.0F, new Dilation(0.0F))
		.uv(0, 0).cuboid(-1.0F, -2.0F, 0.0F, 2.0F, 1.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, -1.0F, 6.0F));

		ModelPartData tail = body2.addChild("tail", ModelPartBuilder.create().uv(18, 0).cuboid(-2.0F, -2.0F, -1.0F, 4.0F, 4.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 1.0F, -6.0F, -0.9599F, 0.0F, 0.0F));

		ModelPartData wings = body.addChild("wings", ModelPartBuilder.create(), ModelTransform.of(0.0F, -2.0F, 4.0F, -0.5236F, 0.0F, 0.0F));

		ModelPartData wingleft = wings.addChild("wingleft", ModelPartBuilder.create().uv(8, 21).cuboid(-1.0F, 0.0F, -2.0F, 1.0F, 3.0F, 3.0F, new Dilation(0.0F)), ModelTransform.pivot(-3.0F, -1.0F, 0.0F));

		ModelPartData wingright = wings.addChild("wingright", ModelPartBuilder.create().uv(0, 23).cuboid(0.0F, 0.0F, -2.0F, 1.0F, 3.0F, 3.0F, new Dilation(0.0F)), ModelTransform.pivot(3.0F, -1.0F, 0.0F));

		ModelPartData feet = body.addChild("feet", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 0.0F, 0.0F));

		ModelPartData footleft = feet.addChild("footleft", ModelPartBuilder.create().uv(15, 12).cuboid(2.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F, new Dilation(0.0F))
		.uv(24, 5).cuboid(2.0F, 1.0F, 0.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F)), ModelTransform.pivot(-1.0F, 0.0F, 3.0F));

		ModelPartData footright = feet.addChild("footright", ModelPartBuilder.create().uv(5, 17).cuboid(-3.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F, new Dilation(0.0F))
		.uv(24, 8).cuboid(-4.0F, 1.0F, 0.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F)), ModelTransform.pivot(1.0F, 0.0F, 3.0F));

		ModelPartData float = modelPartData.addChild("float", ModelPartBuilder.create().uv(20, 56).cuboid(-4.0F, -2.0F, 2.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(20, 40).cuboid(-4.0F, -2.0F, 3.0F, 8.0F, 2.0F, 2.0F, new Dilation(0.01F))
		.uv(20, 52).cuboid(2.0F, -2.0F, 2.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(0, 40).cuboid(3.0F, -2.0F, -4.0F, 2.0F, 2.0F, 8.0F, new Dilation(0.0F))
		.uv(20, 48).cuboid(2.0F, -2.0F, -4.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(0, 50).cuboid(-5.0F, -2.0F, -4.0F, 2.0F, 2.0F, 8.0F, new Dilation(0.0F))
		.uv(20, 44).cuboid(-4.0F, -2.0F, -4.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(0, 60).cuboid(-4.0F, -2.0F, -5.0F, 8.0F, 2.0F, 2.0F, new Dilation(0.02F)), ModelTransform.pivot(0.0F, 24.0F, 0.0F));

		ModelPartData submarine = modelPartData.addChild("submarine", ModelPartBuilder.create().uv(38, 62).cuboid(-7.0F, -12.0F, -6.0F, 14.0F, 13.0F, 13.0F, new Dilation(-0.002F))
		.uv(92, 80).cuboid(-7.0F, -1.0F, -10.0F, 14.0F, 2.0F, 4.0F, new Dilation(0.0F))
		.uv(92, 86).cuboid(-8.0F, -1.0F, 7.0F, 16.0F, 2.0F, 1.0F, new Dilation(0.0F))
		.uv(80, 105).cuboid(-8.0F, -1.0F, -8.0F, 1.0F, 2.0F, 16.0F, new Dilation(0.0F))
		.uv(92, 62).cuboid(7.0F, -1.0F, -8.0F, 1.0F, 2.0F, 16.0F, new Dilation(0.0F))
		.uv(37, 88).cuboid(-7.0F, 1.0F, -7.0F, 14.0F, 2.0F, 15.0F, new Dilation(0.0F))
		.uv(38, 105).cuboid(-4.0F, 3.0F, -5.0F, 8.0F, 1.0F, 13.0F, new Dilation(0.002F))
		.uv(106, 97).cuboid(-5.0F, -1.0F, -1.0F, 2.0F, 2.0F, 5.0F, new Dilation(0.0F))
		.uv(112, 69).cuboid(3.0F, -1.0F, -1.0F, 2.0F, 2.0F, 5.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 20.0F, 0.0F));

		ModelPartData siegeA_r1 = submarine.addChild("siegeA_r1", ModelPartBuilder.create().uv(106, 111).cuboid(-4.0F, -5.0F, 0.0F, 8.0F, 5.0F, 2.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 1.0F, 4.0F, -0.1745F, 0.0F, 0.0F));

		ModelPartData tableaudebord_r1 = submarine.addChild("tableaudebord_r1", ModelPartBuilder.create().uv(44, 125).cuboid(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 2.0F, new Dilation(-0.002F)), ModelTransform.of(0.0F, 1.0F, -5.0F, -0.7854F, 0.0F, 0.0F));

		ModelPartData volant_r1 = submarine.addChild("volant_r1", ModelPartBuilder.create().uv(92, 89).cuboid(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 3.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, -4.0F, -0.7854F, 0.0F, 0.0F));

		ModelPartData propulseA = submarine.addChild("propulseA", ModelPartBuilder.create().uv(92, 97).cuboid(-2.0F, -2.0F, -1.0F, 3.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(-3.0F, 2.0F, 9.0F));

		ModelPartData propulseur = submarine.addChild("propulseur", ModelPartBuilder.create().uv(92, 93).cuboid(-1.0F, -2.0F, -1.0F, 3.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(3.0F, 2.0F, 9.0F));

		ModelPartData jetpack = modelPartData.addChild("jetpack", ModelPartBuilder.create().uv(99, 27).cuboid(3.0F, -5.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(99, 27).cuboid(-5.0F, -5.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(76, 32).cuboid(3.0F, -4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(76, 32).cuboid(-5.0F, -4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(92, 3).cuboid(-2.0F, -2.0F, 1.0F, 4.0F, 5.0F, 3.0F, new Dilation(0.0F))
		.uv(76, 3).cuboid(-6.0F, -4.0F, 1.0F, 4.0F, 7.0F, 4.0F, new Dilation(0.0F))
		.uv(76, 14).cuboid(2.0F, -4.0F, 1.0F, 4.0F, 7.0F, 4.0F, new Dilation(0.0F))
		.uv(100, 11).cuboid(-5.0F, 3.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(100, 14).cuboid(3.0F, 3.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(111, 20).cuboid(-5.0F, 4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(111, 20).cuboid(3.0F, 4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F)), ModelTransform.pivot(0.0F, 18.0F, 3.0F));

		ModelPartData fireB = jetpack.addChild("fireB", ModelPartBuilder.create().uv(76, 25).cuboid(-2.0F, 0.0F, 0.0F, 4.0F, 5.0F, 0.0F, new Dilation(0.0F))
		.uv(92, 20).cuboid(0.0F, 0.0F, -2.0F, 0.0F, 5.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(-4.0F, 4.0F, 3.0F));

		ModelPartData fireA = jetpack.addChild("fireA", ModelPartBuilder.create().uv(84, 25).cuboid(-2.0F, 0.0F, 0.0F, 4.0F, 5.0F, 0.0F, new Dilation(0.0F))
		.uv(92, 11).cuboid(0.0F, 0.0F, -2.0F, 0.0F, 5.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(4.0F, 4.0F, 3.0F));
		return TexturedModelData.of(modelData, 128, 128);
	}
	@Override
	public void setAngles(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}
	@Override
	public void render(MatrixStack matrices, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha) {
		jailbird.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		float.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		submarine.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		jetpack.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
	}
}