// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17+ for Yarn
// Paste this class into your mod and generate all required imports

package com.example.mod;
   
public class sapling - FABRIC extends EntityModel<Entity> {
	private final ModelPart body;
	private final ModelPart leaves;
	private final ModelPart leafright;
	private final ModelPart leafleft;
	private final ModelPart float;
	private final ModelPart jetpack;
	private final ModelPart fireB;
	private final ModelPart fireA;
	private final ModelPart submarine;
	private final ModelPart propulseA;
	private final ModelPart propulseur;
	public sapling - FABRIC(ModelPart root) {
		this.body = root.getChild("body");
		this.leaves = root.getChild("leaves");
		this.leafright = root.getChild("leafright");
		this.leafleft = root.getChild("leafleft");
		this.float = root.getChild("float");
		this.jetpack = root.getChild("jetpack");
		this.fireB = root.getChild("fireB");
		this.fireA = root.getChild("fireA");
		this.submarine = root.getChild("submarine");
		this.propulseA = root.getChild("propulseA");
		this.propulseur = root.getChild("propulseur");
	}
	public static TexturedModelData getTexturedModelData() {
		ModelData modelData = new ModelData();
		ModelPartData modelPartData = modelData.getRoot();
		ModelPartData body = modelPartData.addChild("body", ModelPartBuilder.create().uv(0, 15).cuboid(-3.0F, -8.0F, -4.0F, 6.0F, 9.0F, 8.0F, new Dilation(-0.002F))
		.uv(1, 17).cuboid(-4.0F, -8.0F, -3.0F, 8.0F, 9.0F, 6.0F, new Dilation(-0.001F))
		.uv(1, 1).cuboid(-4.0F, -7.0F, -4.0F, 8.0F, 7.0F, 8.0F, new Dilation(0.0F))
		.uv(28, 24).cuboid(-1.0F, -11.0F, 0.0F, 1.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 23.0F, 1.0F));

		ModelPartData leaves = body.addChild("leaves", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, -11.0F, 0.0F));

		ModelPartData leafright = leaves.addChild("leafright", ModelPartBuilder.create(), ModelTransform.pivot(-1.0F, 0.0F, 0.0F));

		ModelPartData leafright_r1 = leafright.addChild("leafright_r1", ModelPartBuilder.create().uv(34, 23).cuboid(-5.0F, 0.0F, -1.0F, 5.0F, 1.0F, 3.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.2182F));

		ModelPartData leafleft = leaves.addChild("leafleft", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 0.0F, 0.0F));

		ModelPartData leafleft_r1 = leafleft.addChild("leafleft_r1", ModelPartBuilder.create().uv(34, 19).cuboid(0.0F, -1.0F, -1.0F, 5.0F, 1.0F, 3.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 1.0F, 0.0F, 0.0F, 0.0F, -0.2182F));

		ModelPartData float = modelPartData.addChild("float", ModelPartBuilder.create().uv(20, 57).cuboid(-4.0F, -2.0F, 2.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(20, 41).cuboid(-4.0F, -2.0F, 3.0F, 8.0F, 2.0F, 2.0F, new Dilation(0.01F))
		.uv(20, 53).cuboid(2.0F, -2.0F, 2.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(0, 41).cuboid(3.0F, -2.0F, -4.0F, 2.0F, 2.0F, 8.0F, new Dilation(0.0F))
		.uv(20, 49).cuboid(2.0F, -2.0F, -4.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(0, 51).cuboid(-5.0F, -2.0F, -4.0F, 2.0F, 2.0F, 8.0F, new Dilation(0.0F))
		.uv(20, 45).cuboid(-4.0F, -2.0F, -4.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(0, 61).cuboid(-4.0F, -2.0F, -5.0F, 8.0F, 2.0F, 2.0F, new Dilation(0.02F)), ModelTransform.pivot(0.0F, 24.0F, 0.0F));

		ModelPartData jetpack = modelPartData.addChild("jetpack", ModelPartBuilder.create().uv(105, 24).cuboid(3.0F, -5.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(105, 24).cuboid(-5.0F, -5.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(82, 29).cuboid(3.0F, -4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(82, 29).cuboid(-5.0F, -4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(98, 0).cuboid(-2.0F, -2.0F, 1.0F, 4.0F, 5.0F, 3.0F, new Dilation(0.0F))
		.uv(82, 0).cuboid(-6.0F, -4.0F, 1.0F, 4.0F, 7.0F, 4.0F, new Dilation(0.0F))
		.uv(82, 11).cuboid(2.0F, -4.0F, 1.0F, 4.0F, 7.0F, 4.0F, new Dilation(0.0F))
		.uv(106, 8).cuboid(-5.0F, 3.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(106, 11).cuboid(3.0F, 3.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(117, 17).cuboid(-5.0F, 4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(117, 17).cuboid(3.0F, 4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F)), ModelTransform.pivot(0.0F, 14.0F, 3.0F));

		ModelPartData fireB = jetpack.addChild("fireB", ModelPartBuilder.create().uv(82, 22).cuboid(-2.0F, 0.0F, 0.0F, 4.0F, 5.0F, 0.0F, new Dilation(0.0F))
		.uv(98, 17).cuboid(0.0F, 0.0F, -2.0F, 0.0F, 5.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(-4.0F, 4.0F, 3.0F));

		ModelPartData fireA = jetpack.addChild("fireA", ModelPartBuilder.create().uv(90, 22).cuboid(-2.0F, 0.0F, 0.0F, 4.0F, 5.0F, 0.0F, new Dilation(0.0F))
		.uv(98, 8).cuboid(0.0F, 0.0F, -2.0F, 0.0F, 5.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(4.0F, 4.0F, 3.0F));

		ModelPartData submarine = modelPartData.addChild("submarine", ModelPartBuilder.create().uv(38, 62).cuboid(-7.0F, -12.0F, -6.0F, 14.0F, 13.0F, 13.0F, new Dilation(-0.002F))
		.uv(92, 80).cuboid(-7.0F, -1.0F, -10.0F, 14.0F, 2.0F, 4.0F, new Dilation(0.0F))
		.uv(92, 86).cuboid(-8.0F, -1.0F, 7.0F, 16.0F, 2.0F, 1.0F, new Dilation(0.0F))
		.uv(80, 105).cuboid(-8.0F, -1.0F, -8.0F, 1.0F, 2.0F, 16.0F, new Dilation(0.0F))
		.uv(92, 62).cuboid(7.0F, -1.0F, -8.0F, 1.0F, 2.0F, 16.0F, new Dilation(0.0F))
		.uv(37, 88).cuboid(-7.0F, 1.0F, -7.0F, 14.0F, 2.0F, 15.0F, new Dilation(0.0F))
		.uv(38, 105).cuboid(-4.0F, 3.0F, -5.0F, 8.0F, 1.0F, 13.0F, new Dilation(0.002F))
		.uv(106, 97).cuboid(-5.0F, -1.0F, -1.0F, 2.0F, 2.0F, 5.0F, new Dilation(0.0F))
		.uv(112, 69).cuboid(3.0F, -1.0F, -1.0F, 2.0F, 2.0F, 5.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 20.0F, 0.0F));

		ModelPartData siegeA_r1 = submarine.addChild("siegeA_r1", ModelPartBuilder.create().uv(106, 111).cuboid(-4.0F, -5.0F, 0.0F, 8.0F, 5.0F, 2.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 1.0F, 4.0F, -0.1745F, 0.0F, 0.0F));

		ModelPartData tableaudebord_r1 = submarine.addChild("tableaudebord_r1", ModelPartBuilder.create().uv(44, 125).cuboid(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 2.0F, new Dilation(-0.002F)), ModelTransform.of(0.0F, 1.0F, -5.0F, -0.7854F, 0.0F, 0.0F));

		ModelPartData volant_r1 = submarine.addChild("volant_r1", ModelPartBuilder.create().uv(92, 89).cuboid(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 3.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, -4.0F, -0.7854F, 0.0F, 0.0F));

		ModelPartData propulseA = submarine.addChild("propulseA", ModelPartBuilder.create().uv(92, 97).cuboid(-2.0F, -2.0F, -1.0F, 3.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(-3.0F, 2.0F, 9.0F));

		ModelPartData propulseur = submarine.addChild("propulseur", ModelPartBuilder.create().uv(92, 93).cuboid(-1.0F, -2.0F, -1.0F, 3.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(3.0F, 2.0F, 9.0F));
		return TexturedModelData.of(modelData, 128, 128);
	}
	@Override
	public void setAngles(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}
	@Override
	public void render(MatrixStack matrices, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha) {
		body.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		float.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		jetpack.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		submarine.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
	}
}