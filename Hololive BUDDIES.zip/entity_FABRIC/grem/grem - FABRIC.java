// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17+ for Yarn
// Paste this class into your mod and generate all required imports

package com.example.mod;
   
public class grem - FABRIC extends EntityModel<Entity> {
	private final ModelPart grem;
	private final ModelPart tail;
	private final ModelPart tailhand;
	private final ModelPart feet;
	private final ModelPart frontright;
	private final ModelPart frontleft;
	private final ModelPart backright;
	private final ModelPart backleft;
	private final ModelPart float;
	private final ModelPart submarine;
	private final ModelPart propulseA;
	private final ModelPart propulseur;
	private final ModelPart jetpack;
	private final ModelPart fireB;
	private final ModelPart fireA;
	public grem - FABRIC(ModelPart root) {
		this.grem = root.getChild("grem");
		this.tail = root.getChild("tail");
		this.tailhand = root.getChild("tailhand");
		this.feet = root.getChild("feet");
		this.frontright = root.getChild("frontright");
		this.frontleft = root.getChild("frontleft");
		this.backright = root.getChild("backright");
		this.backleft = root.getChild("backleft");
		this.float = root.getChild("float");
		this.submarine = root.getChild("submarine");
		this.propulseA = root.getChild("propulseA");
		this.propulseur = root.getChild("propulseur");
		this.jetpack = root.getChild("jetpack");
		this.fireB = root.getChild("fireB");
		this.fireA = root.getChild("fireA");
	}
	public static TexturedModelData getTexturedModelData() {
		ModelData modelData = new ModelData();
		ModelPartData modelPartData = modelData.getRoot();
		ModelPartData grem = modelPartData.addChild("grem", ModelPartBuilder.create().uv(0, 0).cuboid(-1.0F, -2.0F, -3.0F, 2.0F, 2.0F, 5.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 23.0F, 0.0F));

		ModelPartData tail = grem.addChild("tail", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, -1.0F, 2.0F));

		ModelPartData tail_r1 = tail.addChild("tail_r1", ModelPartBuilder.create().uv(10, 7).cuboid(-0.5F, -1.0F, 0.0F, 1.0F, 1.0F, 3.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, 0.0F, 0.2182F, 0.0F, 0.0F));

		ModelPartData tailhand = tail.addChild("tailhand", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, -1.0F, 3.0F));

		ModelPartData finger3_r1 = tailhand.addChild("finger3_r1", ModelPartBuilder.create().uv(8, 13).cuboid(-0.5F, -1.0F, 0.0F, 1.0F, 1.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(1.0F, -1.0F, 2.0F, 0.0F, 0.3491F, 0.0F));

		ModelPartData finger2_r1 = tailhand.addChild("finger2_r1", ModelPartBuilder.create().uv(4, 13).cuboid(-0.5F, -1.0F, 0.5F, 1.0F, 1.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, -1.0F, 2.0F, 0.1309F, 0.0F, 0.0F));

		ModelPartData finger1_r1 = tailhand.addChild("finger1_r1", ModelPartBuilder.create().uv(0, 13).cuboid(-0.5F, -1.0F, 0.0F, 1.0F, 1.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-1.0F, -1.0F, 2.0F, 0.0F, -0.3491F, 0.0F));

		ModelPartData hand_r1 = tailhand.addChild("hand_r1", ModelPartBuilder.create().uv(0, 7).cuboid(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 3.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, 1.0F, 0.3927F, 0.0F, 0.0F));

		ModelPartData feet = grem.addChild("feet", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 0.0F, 1.0F));

		ModelPartData frontright = feet.addChild("frontright", ModelPartBuilder.create().uv(0, 15).cuboid(-0.5F, -1.0F, -0.5F, 1.0F, 2.0F, 1.0F, new Dilation(-0.01F)), ModelTransform.pivot(-0.5F, 0.0F, -2.5F));

		ModelPartData frontleft = feet.addChild("frontleft", ModelPartBuilder.create().uv(4, 15).cuboid(-0.5F, -1.0F, -0.5F, 1.0F, 2.0F, 1.0F, new Dilation(-0.01F)), ModelTransform.pivot(0.5F, 0.0F, -2.5F));

		ModelPartData backright = feet.addChild("backright", ModelPartBuilder.create().uv(8, 15).cuboid(-0.5F, -1.0F, -0.5F, 1.0F, 2.0F, 1.0F, new Dilation(-0.01F)), ModelTransform.pivot(-0.5F, 0.0F, -0.5F));

		ModelPartData backleft = feet.addChild("backleft", ModelPartBuilder.create().uv(12, 15).cuboid(-0.5F, -1.0F, -0.5F, 1.0F, 2.0F, 1.0F, new Dilation(-0.01F)), ModelTransform.pivot(0.5F, 0.0F, -0.5F));

		ModelPartData float = modelPartData.addChild("float", ModelPartBuilder.create().uv(44, 16).cuboid(-4.0F, -2.0F, 2.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(44, 0).cuboid(-4.0F, -2.0F, 3.0F, 8.0F, 2.0F, 2.0F, new Dilation(0.01F))
		.uv(44, 12).cuboid(2.0F, -2.0F, 2.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(24, 0).cuboid(3.0F, -2.0F, -4.0F, 2.0F, 2.0F, 8.0F, new Dilation(0.0F))
		.uv(44, 8).cuboid(2.0F, -2.0F, -4.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(24, 10).cuboid(-5.0F, -2.0F, -4.0F, 2.0F, 2.0F, 8.0F, new Dilation(0.0F))
		.uv(44, 4).cuboid(-4.0F, -2.0F, -4.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(24, 20).cuboid(-4.0F, -2.0F, -5.0F, 8.0F, 2.0F, 2.0F, new Dilation(0.02F)), ModelTransform.pivot(0.0F, 24.0F, 0.0F));

		ModelPartData submarine = modelPartData.addChild("submarine", ModelPartBuilder.create().uv(110, 2).cuboid(-7.0F, -12.0F, -6.0F, 14.0F, 13.0F, 13.0F, new Dilation(-0.002F))
		.uv(164, 20).cuboid(-7.0F, -1.0F, -10.0F, 14.0F, 2.0F, 4.0F, new Dilation(0.0F))
		.uv(164, 26).cuboid(-8.0F, -1.0F, 7.0F, 16.0F, 2.0F, 1.0F, new Dilation(0.0F))
		.uv(152, 45).cuboid(-8.0F, -1.0F, -8.0F, 1.0F, 2.0F, 16.0F, new Dilation(0.0F))
		.uv(164, 2).cuboid(7.0F, -1.0F, -8.0F, 1.0F, 2.0F, 16.0F, new Dilation(0.0F))
		.uv(109, 28).cuboid(-7.0F, 1.0F, -7.0F, 14.0F, 2.0F, 15.0F, new Dilation(0.0F))
		.uv(110, 45).cuboid(-4.0F, 3.0F, -5.0F, 8.0F, 1.0F, 13.0F, new Dilation(0.002F))
		.uv(178, 37).cuboid(-5.0F, -1.0F, -1.0F, 2.0F, 2.0F, 5.0F, new Dilation(0.0F))
		.uv(184, 9).cuboid(3.0F, -1.0F, -1.0F, 2.0F, 2.0F, 5.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 20.0F, 0.0F));

		ModelPartData siegeA_r1 = submarine.addChild("siegeA_r1", ModelPartBuilder.create().uv(178, 51).cuboid(-4.0F, -5.0F, 0.0F, 8.0F, 5.0F, 2.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 1.0F, 4.0F, -0.1745F, 0.0F, 0.0F));

		ModelPartData tableaudebord_r1 = submarine.addChild("tableaudebord_r1", ModelPartBuilder.create().uv(116, 65).cuboid(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 2.0F, new Dilation(-0.002F)), ModelTransform.of(0.0F, 1.0F, -5.0F, -0.7854F, 0.0F, 0.0F));

		ModelPartData volant_r1 = submarine.addChild("volant_r1", ModelPartBuilder.create().uv(164, 29).cuboid(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 3.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, -4.0F, -0.7854F, 0.0F, 0.0F));

		ModelPartData propulseA = submarine.addChild("propulseA", ModelPartBuilder.create().uv(164, 37).cuboid(-2.0F, -2.0F, -1.0F, 3.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(-3.0F, 2.0F, 9.0F));

		ModelPartData propulseur = submarine.addChild("propulseur", ModelPartBuilder.create().uv(164, 33).cuboid(-1.0F, -2.0F, -1.0F, 3.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(3.0F, 2.0F, 9.0F));

		ModelPartData jetpack = modelPartData.addChild("jetpack", ModelPartBuilder.create().uv(178, 192).cuboid(3.0F, -5.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(178, 192).cuboid(-5.0F, -5.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(156, 197).cuboid(3.0F, -4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(156, 197).cuboid(-5.0F, -4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(171, 168).cuboid(-2.0F, -2.0F, 1.0F, 4.0F, 5.0F, 3.0F, new Dilation(0.0F))
		.uv(155, 168).cuboid(-6.0F, -4.0F, 1.0F, 4.0F, 7.0F, 4.0F, new Dilation(0.0F))
		.uv(155, 179).cuboid(2.0F, -4.0F, 1.0F, 4.0F, 7.0F, 4.0F, new Dilation(0.0F))
		.uv(179, 176).cuboid(-5.0F, 3.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(179, 179).cuboid(3.0F, 3.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(190, 185).cuboid(-5.0F, 4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(190, 185).cuboid(3.0F, 4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F)), ModelTransform.pivot(0.0F, 14.0F, 3.0F));

		ModelPartData fireB = jetpack.addChild("fireB", ModelPartBuilder.create().uv(155, 190).cuboid(-2.0F, 0.0F, 0.0F, 4.0F, 5.0F, 0.0F, new Dilation(0.0F))
		.uv(171, 185).cuboid(0.0F, 0.0F, -2.0F, 0.0F, 5.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(-4.0F, 4.0F, 3.0F));

		ModelPartData fireA = jetpack.addChild("fireA", ModelPartBuilder.create().uv(163, 190).cuboid(-2.0F, 0.0F, 0.0F, 4.0F, 5.0F, 0.0F, new Dilation(0.0F))
		.uv(171, 176).cuboid(0.0F, 0.0F, -2.0F, 0.0F, 5.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(4.0F, 4.0F, 3.0F));
		return TexturedModelData.of(modelData, 200, 200);
	}
	@Override
	public void setAngles(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}
	@Override
	public void render(MatrixStack matrices, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha) {
		grem.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		float.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		submarine.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		jetpack.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
	}
}