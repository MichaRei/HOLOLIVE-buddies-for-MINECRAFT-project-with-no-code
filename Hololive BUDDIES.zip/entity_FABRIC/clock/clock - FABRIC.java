// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17+ for Yarn
// Paste this class into your mod and generate all required imports

package com.example.mod;
   
public class clock - FABRIC extends EntityModel<Entity> {
	private final ModelPart clock;
	private final ModelPart upperbody;
	private final ModelPart armleft;
	private final ModelPart armright;
	private final ModelPart butterfly;
	private final ModelPart hat;
	private final ModelPart key;
	private final ModelPart timehour;
	private final ModelPart timeminute;
	private final ModelPart timesecond;
	private final ModelPart footleft;
	private final ModelPart footright;
	private final ModelPart float;
	private final ModelPart jetpack;
	private final ModelPart fireB;
	private final ModelPart fireA;
	private final ModelPart submarine;
	private final ModelPart propulseA;
	private final ModelPart propulseur;
	private final ModelPart accoudoirB;
	private final ModelPart accoudoir;
	public clock - FABRIC(ModelPart root) {
		this.clock = root.getChild("clock");
		this.upperbody = root.getChild("upperbody");
		this.armleft = root.getChild("armleft");
		this.armright = root.getChild("armright");
		this.butterfly = root.getChild("butterfly");
		this.hat = root.getChild("hat");
		this.key = root.getChild("key");
		this.timehour = root.getChild("timehour");
		this.timeminute = root.getChild("timeminute");
		this.timesecond = root.getChild("timesecond");
		this.footleft = root.getChild("footleft");
		this.footright = root.getChild("footright");
		this.float = root.getChild("float");
		this.jetpack = root.getChild("jetpack");
		this.fireB = root.getChild("fireB");
		this.fireA = root.getChild("fireA");
		this.submarine = root.getChild("submarine");
		this.propulseA = root.getChild("propulseA");
		this.propulseur = root.getChild("propulseur");
		this.accoudoirB = root.getChild("accoudoirB");
		this.accoudoir = root.getChild("accoudoir");
	}
	public static TexturedModelData getTexturedModelData() {
		ModelData modelData = new ModelData();
		ModelPartData modelPartData = modelData.getRoot();
		ModelPartData clock = modelPartData.addChild("clock", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 22.0F, 0.0F));

		ModelPartData upperbody = clock.addChild("upperbody", ModelPartBuilder.create().uv(29, 34).cuboid(-1.0F, -1.5F, -5.5F, 2.0F, 2.0F, 1.0F, new Dilation(-0.07F))
		.uv(0, 0).cuboid(-5.0F, -4.5F, -4.5F, 10.0F, 8.0F, 4.0F, new Dilation(-0.002F))
		.uv(0, 12).cuboid(-4.0F, -5.5F, -4.5F, 8.0F, 10.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, -3.5F, 2.5F));

		ModelPartData earright_r1 = upperbody.addChild("earright_r1", ModelPartBuilder.create().uv(0, 26).cuboid(-2.0F, -2.0F, -1.5F, 3.0F, 2.0F, 3.0F, new Dilation(0.0F)), ModelTransform.of(-3.0F, -5.5F, -2.5F, 0.0F, 0.0F, -0.5236F));

		ModelPartData earleft_r1 = upperbody.addChild("earleft_r1", ModelPartBuilder.create().uv(24, 23).cuboid(-1.0F, -2.0F, -1.5F, 3.0F, 2.0F, 3.0F, new Dilation(0.0F)), ModelTransform.of(3.0F, -5.5F, -2.5F, 0.0F, 0.0F, 0.5236F));

		ModelPartData armleft = upperbody.addChild("armleft", ModelPartBuilder.create().uv(28, 0).cuboid(-2.0F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F, new Dilation(0.0F)), ModelTransform.pivot(-5.0F, 1.5F, -2.5F));

		ModelPartData armright = upperbody.addChild("armright", ModelPartBuilder.create().uv(12, 26).cuboid(-1.0F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F, new Dilation(0.0F)), ModelTransform.pivot(5.0F, 1.5F, -2.5F));

		ModelPartData butterfly = upperbody.addChild("butterfly", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 3.5F, -4.0F));

		ModelPartData band_r1 = butterfly.addChild("band_r1", ModelPartBuilder.create().uv(22, 28).cuboid(-1.5F, -1.0F, -0.5F, 3.0F, 2.0F, 0.0F, new Dilation(0.05F)), ModelTransform.of(0.0F, 0.0F, 0.0F, -0.0436F, 0.0F, 0.0F));

		ModelPartData hat = upperbody.addChild("hat", ModelPartBuilder.create().uv(24, 17).cuboid(-1.5F, -5.0F, -1.5F, 3.0F, 3.0F, 3.0F, new Dilation(-0.05F))
		.uv(24, 12).cuboid(-2.0F, -2.0F, -2.0F, 4.0F, 1.0F, 4.0F, new Dilation(-0.05F)), ModelTransform.pivot(0.0F, -4.5F, -2.5F));

		ModelPartData key = upperbody.addChild("key", ModelPartBuilder.create().uv(39, 3).cuboid(-0.5F, -0.5F, -1.0F, 1.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(42, 18).cuboid(-0.5F, -2.0F, 1.0F, 1.0F, 4.0F, 2.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 0.0F, 0.0F));

		ModelPartData timehour = upperbody.addChild("timehour", ModelPartBuilder.create().uv(6, 46).cuboid(-0.5F, -3.0F, -0.5F, 1.0F, 3.0F, 1.0F, new Dilation(0.02F)), ModelTransform.pivot(0.0F, -0.5F, -4.5F));

		ModelPartData timeminute = upperbody.addChild("timeminute", ModelPartBuilder.create().uv(6, 46).cuboid(-0.5F, -4.0F, -0.5F, 1.0F, 4.0F, 1.0F, new Dilation(-0.02F)), ModelTransform.pivot(0.0F, -0.5F, -4.5F));

		ModelPartData timesecond = upperbody.addChild("timesecond", ModelPartBuilder.create().uv(15, 46).cuboid(-0.5F, -4.5F, -0.5F, 1.0F, 4.0F, 1.0F, new Dilation(-0.05F)), ModelTransform.pivot(0.0F, -0.5F, -4.5F));

		ModelPartData footleft = clock.addChild("footleft", ModelPartBuilder.create().uv(28, 8).cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F, new Dilation(0.0F)), ModelTransform.pivot(2.0F, 0.0F, 0.0F));

		ModelPartData footright = clock.addChild("footright", ModelPartBuilder.create().uv(28, 4).cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F, new Dilation(0.0F)), ModelTransform.pivot(-2.0F, 0.0F, 0.0F));

		ModelPartData float = modelPartData.addChild("float", ModelPartBuilder.create().uv(20, 78).cuboid(-4.0F, -2.0F, 2.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(20, 62).cuboid(-4.0F, -2.0F, 3.0F, 8.0F, 2.0F, 2.0F, new Dilation(0.01F))
		.uv(20, 74).cuboid(2.0F, -2.0F, 2.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(0, 62).cuboid(3.0F, -2.0F, -4.0F, 2.0F, 2.0F, 8.0F, new Dilation(0.0F))
		.uv(20, 70).cuboid(2.0F, -2.0F, -4.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(0, 72).cuboid(-5.0F, -2.0F, -4.0F, 2.0F, 2.0F, 8.0F, new Dilation(0.0F))
		.uv(20, 66).cuboid(-4.0F, -2.0F, -4.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(0, 82).cuboid(-4.0F, -2.0F, -5.0F, 8.0F, 2.0F, 2.0F, new Dilation(0.02F)), ModelTransform.pivot(0.0F, 24.0F, 0.0F));

		ModelPartData jetpack = modelPartData.addChild("jetpack", ModelPartBuilder.create().uv(100, 24).cuboid(3.0F, -5.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(100, 24).cuboid(-5.0F, -5.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(77, 29).cuboid(3.0F, -4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(77, 29).cuboid(-5.0F, -4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(93, 0).cuboid(-2.0F, -2.0F, 1.0F, 4.0F, 5.0F, 3.0F, new Dilation(0.0F))
		.uv(77, 0).cuboid(-6.0F, -4.0F, 1.0F, 4.0F, 7.0F, 4.0F, new Dilation(0.0F))
		.uv(77, 11).cuboid(2.0F, -4.0F, 1.0F, 4.0F, 7.0F, 4.0F, new Dilation(0.0F))
		.uv(101, 8).cuboid(-5.0F, 3.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(101, 11).cuboid(3.0F, 3.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(112, 17).cuboid(-5.0F, 4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(112, 17).cuboid(3.0F, 4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F)), ModelTransform.pivot(0.0F, 14.0F, 3.0F));

		ModelPartData fireB = jetpack.addChild("fireB", ModelPartBuilder.create().uv(77, 22).cuboid(-2.0F, 0.0F, 0.0F, 4.0F, 5.0F, 0.0F, new Dilation(0.0F))
		.uv(93, 17).cuboid(0.0F, 0.0F, -2.0F, 0.0F, 5.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(-4.0F, 4.0F, 3.0F));

		ModelPartData fireA = jetpack.addChild("fireA", ModelPartBuilder.create().uv(85, 22).cuboid(-2.0F, 0.0F, 0.0F, 4.0F, 5.0F, 0.0F, new Dilation(0.0F))
		.uv(93, 8).cuboid(0.0F, 0.0F, -2.0F, 0.0F, 5.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(4.0F, 4.0F, 3.0F));

		ModelPartData submarine = modelPartData.addChild("submarine", ModelPartBuilder.create().uv(38, 62).cuboid(-7.0F, -12.0F, -6.0F, 14.0F, 13.0F, 13.0F, new Dilation(0.002F))
		.uv(92, 80).cuboid(-7.0F, -1.0F, -10.0F, 14.0F, 2.0F, 4.0F, new Dilation(0.002F))
		.uv(92, 86).cuboid(-8.0F, -1.0F, 7.0F, 16.0F, 2.0F, 1.0F, new Dilation(0.002F))
		.uv(80, 105).cuboid(-8.0F, -1.0F, -8.0F, 1.0F, 2.0F, 16.0F, new Dilation(0.002F))
		.uv(92, 62).cuboid(7.0F, -1.0F, -8.0F, 1.0F, 2.0F, 16.0F, new Dilation(0.002F))
		.uv(37, 88).cuboid(-7.0F, 1.0F, -7.0F, 14.0F, 2.0F, 15.0F, new Dilation(0.002F))
		.uv(38, 105).cuboid(-4.0F, 3.0F, -5.0F, 8.0F, 1.0F, 13.0F, new Dilation(0.002F)), ModelTransform.pivot(0.0F, 20.0F, 0.0F));

		ModelPartData siegeA_r1 = submarine.addChild("siegeA_r1", ModelPartBuilder.create().uv(106, 111).cuboid(-4.0F, -5.0F, 0.0F, 8.0F, 5.0F, 2.0F, new Dilation(0.002F)), ModelTransform.of(0.0F, 1.0F, 4.0F, -0.1745F, 0.0F, 0.0F));

		ModelPartData tableaudebord_r1 = submarine.addChild("tableaudebord_r1", ModelPartBuilder.create().uv(44, 125).cuboid(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 2.0F, new Dilation(0.002F)), ModelTransform.of(0.0F, 1.0F, -5.0F, -0.7854F, 0.0F, 0.0F));

		ModelPartData volant_r1 = submarine.addChild("volant_r1", ModelPartBuilder.create().uv(92, 89).cuboid(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 3.0F, new Dilation(0.002F)), ModelTransform.of(0.0F, 0.0F, -4.0F, -0.7854F, 0.0F, 0.0F));

		ModelPartData propulseA = submarine.addChild("propulseA", ModelPartBuilder.create().uv(92, 97).cuboid(-2.0F, -2.0F, -1.0F, 3.0F, 3.0F, 1.0F, new Dilation(0.002F)), ModelTransform.pivot(-3.0F, 2.0F, 9.0F));

		ModelPartData propulseur = submarine.addChild("propulseur", ModelPartBuilder.create().uv(92, 93).cuboid(-1.0F, -2.0F, -1.0F, 3.0F, 3.0F, 1.0F, new Dilation(0.002F)), ModelTransform.pivot(3.0F, 2.0F, 9.0F));

		ModelPartData accoudoirB = submarine.addChild("accoudoirB", ModelPartBuilder.create().uv(112, 69).cuboid(-1.0F, -2.0F, -4.0F, 2.0F, 2.0F, 5.0F, new Dilation(0.002F)), ModelTransform.pivot(4.0F, 1.0F, 3.0F));

		ModelPartData accoudoir = submarine.addChild("accoudoir", ModelPartBuilder.create().uv(106, 97).cuboid(-1.0F, -2.0F, -4.0F, 2.0F, 2.0F, 5.0F, new Dilation(0.002F)), ModelTransform.pivot(-4.0F, 1.0F, 3.0F));
		return TexturedModelData.of(modelData, 128, 128);
	}
	@Override
	public void setAngles(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}
	@Override
	public void render(MatrixStack matrices, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha) {
		clock.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		float.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		jetpack.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		submarine.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
	}
}