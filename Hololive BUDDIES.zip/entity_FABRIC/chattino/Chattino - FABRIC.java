// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17+ for Yarn
// Paste this class into your mod and generate all required imports

package com.example.mod;
   
public class Chattino - FABRIC extends EntityModel<Entity> {
	private final ModelPart chattino;
	private final ModelPart body;
	private final ModelPart upperbody;
	private final ModelPart head;
	private final ModelPart earfluff;
	private final ModelPart fluffright;
	private final ModelPart fluffleft;
	private final ModelPart earleft;
	private final ModelPart earright;
	private final ModelPart armleft;
	private final ModelPart armright;
	private final ModelPart tail;
	private final ModelPart rightleg;
	private final ModelPart leftleg;
	private final ModelPart float;
	private final ModelPart jetpack;
	private final ModelPart fireB;
	private final ModelPart fireA;
	private final ModelPart submarine;
	private final ModelPart propulseA;
	private final ModelPart propulseur;
	public Chattino - FABRIC(ModelPart root) {
		this.chattino = root.getChild("chattino");
		this.body = root.getChild("body");
		this.upperbody = root.getChild("upperbody");
		this.head = root.getChild("head");
		this.earfluff = root.getChild("earfluff");
		this.fluffright = root.getChild("fluffright");
		this.fluffleft = root.getChild("fluffleft");
		this.earleft = root.getChild("earleft");
		this.earright = root.getChild("earright");
		this.armleft = root.getChild("armleft");
		this.armright = root.getChild("armright");
		this.tail = root.getChild("tail");
		this.rightleg = root.getChild("rightleg");
		this.leftleg = root.getChild("leftleg");
		this.float = root.getChild("float");
		this.jetpack = root.getChild("jetpack");
		this.fireB = root.getChild("fireB");
		this.fireA = root.getChild("fireA");
		this.submarine = root.getChild("submarine");
		this.propulseA = root.getChild("propulseA");
		this.propulseur = root.getChild("propulseur");
	}
	public static TexturedModelData getTexturedModelData() {
		ModelData modelData = new ModelData();
		ModelPartData modelPartData = modelData.getRoot();
		ModelPartData chattino = modelPartData.addChild("chattino", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 23.0F, -1.0F));

		ModelPartData body = chattino.addChild("body", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, -4.0F, 1.0F));

		ModelPartData upperbody = body.addChild("upperbody", ModelPartBuilder.create().uv(0, 11).cuboid(-2.0F, -1.0F, -2.0F, 4.0F, 5.0F, 3.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 0.0F, 0.0F));

		ModelPartData head = upperbody.addChild("head", ModelPartBuilder.create().uv(0, 0).cuboid(-3.0F, -6.0F, -2.0F, 6.0F, 6.0F, 5.0F, new Dilation(0.0F))
		.uv(1, 20).cuboid(3.0F, -2.0F, -2.0F, 1.0F, 2.0F, 1.0F, new Dilation(0.0F))
		.uv(7, 20).cuboid(-4.0F, -2.0F, -2.0F, 1.0F, 2.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, -1.0F, -1.0F));

		ModelPartData earfluff = head.addChild("earfluff", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, -6.0F, 1.0F));

		ModelPartData fluffright = earfluff.addChild("fluffright", ModelPartBuilder.create().uv(22, 8).cuboid(-1.0F, -1.0F, -1.0F, 1.0F, 1.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.0873F));

		ModelPartData fluffleft = earfluff.addChild("fluffleft", ModelPartBuilder.create().uv(0, 23).cuboid(0.0F, -1.0F, -1.0F, 1.0F, 1.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0873F));

		ModelPartData earleft = head.addChild("earleft", ModelPartBuilder.create().uv(14, 11).cuboid(-1.0F, -4.0F, -1.0F, 3.0F, 4.0F, 2.0F, new Dilation(0.0F)), ModelTransform.of(2.0F, -5.0F, 1.0F, 0.0F, 0.0F, 0.1309F));

		ModelPartData earright = head.addChild("earright", ModelPartBuilder.create().uv(14, 17).cuboid(-2.0F, -4.0F, -1.0F, 3.0F, 4.0F, 2.0F, new Dilation(0.0F)), ModelTransform.of(-2.0F, -5.0F, 1.0F, 0.0F, 0.0F, -0.1309F));

		ModelPartData armleft = upperbody.addChild("armleft", ModelPartBuilder.create().uv(22, 0).cuboid(0.0F, 0.0F, -1.0F, 1.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(2.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.0873F));

		ModelPartData armright = upperbody.addChild("armright", ModelPartBuilder.create().uv(22, 4).cuboid(-1.0F, 0.0F, -1.0F, 1.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(-2.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0873F));

		ModelPartData tail = upperbody.addChild("tail", ModelPartBuilder.create().uv(24, 10).cuboid(-0.5F, -0.5F, -1.0F, 1.0F, 1.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 3.0F, 1.0F));

		ModelPartData rightleg = body.addChild("rightleg", ModelPartBuilder.create().uv(4, 23).cuboid(0.0F, 0.0F, -1.0F, 1.0F, 1.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(-2.0F, 4.0F, 0.0F));

		ModelPartData leftleg = body.addChild("leftleg", ModelPartBuilder.create().uv(8, 23).cuboid(-1.0F, 0.0F, -1.0F, 1.0F, 1.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(2.0F, 4.0F, 0.0F));

		ModelPartData float = modelPartData.addChild("float", ModelPartBuilder.create().uv(20, 45).cuboid(-4.0F, -2.0F, 2.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(20, 29).cuboid(-4.0F, -2.0F, 3.0F, 8.0F, 2.0F, 2.0F, new Dilation(0.01F))
		.uv(20, 41).cuboid(2.0F, -2.0F, 2.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(0, 29).cuboid(3.0F, -2.0F, -4.0F, 2.0F, 2.0F, 8.0F, new Dilation(0.0F))
		.uv(20, 37).cuboid(2.0F, -2.0F, -4.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(0, 39).cuboid(-5.0F, -2.0F, -4.0F, 2.0F, 2.0F, 8.0F, new Dilation(0.0F))
		.uv(20, 33).cuboid(-4.0F, -2.0F, -4.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(0, 49).cuboid(-4.0F, -2.0F, -5.0F, 8.0F, 2.0F, 2.0F, new Dilation(0.02F)), ModelTransform.pivot(0.0F, 24.0F, 0.0F));

		ModelPartData jetpack = modelPartData.addChild("jetpack", ModelPartBuilder.create().uv(68, 25).cuboid(3.0F, -5.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(68, 25).cuboid(-5.0F, -5.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(44, 30).cuboid(3.0F, -4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(44, 30).cuboid(-5.0F, -4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(61, 1).cuboid(-2.0F, -2.0F, 1.0F, 4.0F, 5.0F, 3.0F, new Dilation(0.0F))
		.uv(45, 1).cuboid(-6.0F, -4.0F, 1.0F, 4.0F, 7.0F, 4.0F, new Dilation(0.0F))
		.uv(45, 12).cuboid(2.0F, -4.0F, 1.0F, 4.0F, 7.0F, 4.0F, new Dilation(0.0F))
		.uv(69, 9).cuboid(-5.0F, 3.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(69, 12).cuboid(3.0F, 3.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(80, 18).cuboid(-5.0F, 4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(80, 18).cuboid(3.0F, 4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F)), ModelTransform.pivot(0.0F, 18.0F, 2.0F));

		ModelPartData fireB = jetpack.addChild("fireB", ModelPartBuilder.create().uv(45, 23).cuboid(-2.0F, 0.0F, 0.0F, 4.0F, 5.0F, 0.0F, new Dilation(0.0F))
		.uv(61, 18).cuboid(0.0F, 0.0F, -2.0F, 0.0F, 5.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(-4.0F, 4.0F, 3.0F));

		ModelPartData fireA = jetpack.addChild("fireA", ModelPartBuilder.create().uv(53, 23).cuboid(-2.0F, 0.0F, 0.0F, 4.0F, 5.0F, 0.0F, new Dilation(0.0F))
		.uv(61, 9).cuboid(0.0F, 0.0F, -2.0F, 0.0F, 5.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(4.0F, 4.0F, 3.0F));

		ModelPartData submarine = modelPartData.addChild("submarine", ModelPartBuilder.create().uv(30, 57).cuboid(-7.0F, -12.0F, -6.0F, 14.0F, 13.0F, 13.0F, new Dilation(-0.002F))
		.uv(84, 75).cuboid(-7.0F, -1.0F, -10.0F, 14.0F, 2.0F, 4.0F, new Dilation(0.0F))
		.uv(84, 81).cuboid(-8.0F, -1.0F, 7.0F, 16.0F, 2.0F, 1.0F, new Dilation(0.0F))
		.uv(72, 100).cuboid(-8.0F, -1.0F, -8.0F, 1.0F, 2.0F, 16.0F, new Dilation(0.0F))
		.uv(84, 57).cuboid(7.0F, -1.0F, -8.0F, 1.0F, 2.0F, 16.0F, new Dilation(0.0F))
		.uv(29, 83).cuboid(-7.0F, 1.0F, -7.0F, 14.0F, 2.0F, 15.0F, new Dilation(0.0F))
		.uv(30, 100).cuboid(-4.0F, 3.0F, -5.0F, 8.0F, 1.0F, 13.0F, new Dilation(0.002F))
		.uv(98, 92).cuboid(-5.0F, -1.0F, -1.0F, 2.0F, 2.0F, 5.0F, new Dilation(0.0F))
		.uv(104, 64).cuboid(3.0F, -1.0F, -1.0F, 2.0F, 2.0F, 5.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 20.0F, 0.0F));

		ModelPartData siegeA_r1 = submarine.addChild("siegeA_r1", ModelPartBuilder.create().uv(98, 106).cuboid(-4.0F, -5.0F, 0.0F, 8.0F, 5.0F, 2.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 1.0F, 4.0F, -0.1745F, 0.0F, 0.0F));

		ModelPartData tableaudebord_r1 = submarine.addChild("tableaudebord_r1", ModelPartBuilder.create().uv(36, 120).cuboid(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 2.0F, new Dilation(-0.002F)), ModelTransform.of(0.0F, 1.0F, -5.0F, -0.7854F, 0.0F, 0.0F));

		ModelPartData volant_r1 = submarine.addChild("volant_r1", ModelPartBuilder.create().uv(84, 84).cuboid(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 3.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, -4.0F, -0.7854F, 0.0F, 0.0F));

		ModelPartData propulseA = submarine.addChild("propulseA", ModelPartBuilder.create().uv(84, 92).cuboid(-2.0F, -2.0F, -1.0F, 3.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(-3.0F, 2.0F, 9.0F));

		ModelPartData propulseur = submarine.addChild("propulseur", ModelPartBuilder.create().uv(84, 88).cuboid(-1.0F, -2.0F, -1.0F, 3.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(3.0F, 2.0F, 9.0F));
		return TexturedModelData.of(modelData, 128, 128);
	}
	@Override
	public void setAngles(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}
	@Override
	public void render(MatrixStack matrices, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha) {
		chattino.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		float.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		jetpack.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		submarine.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
	}
}