// Made with Blockbench 4.12.5
// Exported for Minecraft version 1.17+ for Yarn
// Paste this class into your mod and generate all required imports

package com.example.mod;
   
public class KFP - FABRIC extends EntityModel<Entity> {
	private final ModelPart kfp;
	private final ModelPart body;
	private final ModelPart hat;
	private final ModelPart wings;
	private final ModelPart wingleft;
	private final ModelPart wingright;
	private final ModelPart tail;
	private final ModelPart feet;
	private final ModelPart footleft;
	private final ModelPart footright;
	private final ModelPart jetpack;
	private final ModelPart fireB;
	private final ModelPart fireA;
	private final ModelPart submarine;
	private final ModelPart propulseA;
	private final ModelPart propulseur;
	private final ModelPart float;
	public KFP - FABRIC(ModelPart root) {
		this.kfp = root.getChild("kfp");
		this.body = root.getChild("body");
		this.hat = root.getChild("hat");
		this.wings = root.getChild("wings");
		this.wingleft = root.getChild("wingleft");
		this.wingright = root.getChild("wingright");
		this.tail = root.getChild("tail");
		this.feet = root.getChild("feet");
		this.footleft = root.getChild("footleft");
		this.footright = root.getChild("footright");
		this.jetpack = root.getChild("jetpack");
		this.fireB = root.getChild("fireB");
		this.fireA = root.getChild("fireA");
		this.submarine = root.getChild("submarine");
		this.propulseA = root.getChild("propulseA");
		this.propulseur = root.getChild("propulseur");
		this.float = root.getChild("float");
	}
	public static TexturedModelData getTexturedModelData() {
		ModelData modelData = new ModelData();
		ModelPartData modelPartData = modelData.getRoot();
		ModelPartData kfp = modelPartData.addChild("kfp", ModelPartBuilder.create(), ModelTransform.of(0.0F, 22.0F, 3.0F, 0.0F, 3.1416F, 0.0F));

		ModelPartData body = kfp.addChild("body", ModelPartBuilder.create().uv(0, 0).cuboid(-3.0F, -4.0F, -2.0F, 6.0F, 6.0F, 6.0F, new Dilation(0.0F))
		.uv(24, 6).cuboid(-1.0F, -2.0F, 4.0F, 2.0F, 1.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, -2.0F, 2.0F));

		ModelPartData hat = body.addChild("hat", ModelPartBuilder.create().uv(0, 12).cuboid(-3.0F, -2.0F, -3.0F, 6.0F, 2.0F, 6.0F, new Dilation(0.0F))
		.uv(1, 21).cuboid(-2.0F, -1.0F, 3.0F, 4.0F, 1.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, -4.0F, 1.0F));

		ModelPartData wings = body.addChild("wings", ModelPartBuilder.create(), ModelTransform.of(0.0F, 0.0F, 2.0F, -0.5236F, 0.0F, 0.0F));

		ModelPartData wingleft = wings.addChild("wingleft", ModelPartBuilder.create().uv(22, 20).cuboid(-1.0F, 0.0F, -2.0F, 1.0F, 3.0F, 3.0F, new Dilation(0.0F)), ModelTransform.pivot(-3.0F, -1.0F, 0.0F));

		ModelPartData wingright = wings.addChild("wingright", ModelPartBuilder.create().uv(0, 23).cuboid(0.0F, 0.0F, -2.0F, 1.0F, 3.0F, 3.0F, new Dilation(0.0F)), ModelTransform.pivot(3.0F, -1.0F, 0.0F));

		ModelPartData tail = body.addChild("tail", ModelPartBuilder.create().uv(12, 20).cuboid(-2.0F, -2.0F, -1.0F, 4.0F, 4.0F, 1.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 2.0F, -2.0F, -0.9599F, 0.0F, 0.0F));

		ModelPartData feet = kfp.addChild("feet", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 0.0F, 0.0F));

		ModelPartData footleft = feet.addChild("footleft", ModelPartBuilder.create().uv(8, 23).cuboid(2.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F, new Dilation(0.0F))
		.uv(24, 0).cuboid(2.0F, 1.0F, 0.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F)), ModelTransform.pivot(-1.0F, 0.0F, 3.0F));

		ModelPartData footright = feet.addChild("footright", ModelPartBuilder.create().uv(24, 8).cuboid(-3.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F, new Dilation(0.0F))
		.uv(24, 3).cuboid(-4.0F, 1.0F, 0.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F)), ModelTransform.pivot(1.0F, 0.0F, 3.0F));

		ModelPartData jetpack = modelPartData.addChild("jetpack", ModelPartBuilder.create().uv(110, 24).cuboid(3.0F, -5.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(110, 24).cuboid(-5.0F, -5.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(87, 29).cuboid(3.0F, -4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(87, 29).cuboid(-5.0F, -4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(103, 0).cuboid(-2.0F, -2.0F, 1.0F, 4.0F, 5.0F, 3.0F, new Dilation(0.0F))
		.uv(87, 0).cuboid(-6.0F, -4.0F, 1.0F, 4.0F, 7.0F, 4.0F, new Dilation(0.0F))
		.uv(87, 11).cuboid(2.0F, -4.0F, 1.0F, 4.0F, 7.0F, 4.0F, new Dilation(0.0F))
		.uv(111, 8).cuboid(-5.0F, 3.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(111, 11).cuboid(3.0F, 3.0F, 2.0F, 2.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(122, 17).cuboid(-5.0F, 4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F))
		.uv(122, 17).cuboid(3.0F, 4.0F, 2.0F, 2.0F, 0.0F, 2.0F, new Dilation(0.5F)), ModelTransform.pivot(0.0F, 14.0F, 3.0F));

		ModelPartData fireB = jetpack.addChild("fireB", ModelPartBuilder.create().uv(87, 22).cuboid(-2.0F, 0.0F, 0.0F, 4.0F, 5.0F, 0.0F, new Dilation(0.0F))
		.uv(103, 17).cuboid(0.0F, 0.0F, -2.0F, 0.0F, 5.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(-4.0F, 4.0F, 3.0F));

		ModelPartData fireA = jetpack.addChild("fireA", ModelPartBuilder.create().uv(95, 22).cuboid(-2.0F, 0.0F, 0.0F, 4.0F, 5.0F, 0.0F, new Dilation(0.0F))
		.uv(103, 8).cuboid(0.0F, 0.0F, -2.0F, 0.0F, 5.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(4.0F, 4.0F, 3.0F));

		ModelPartData submarine = modelPartData.addChild("submarine", ModelPartBuilder.create().uv(38, 62).cuboid(-7.0F, -12.0F, -6.0F, 14.0F, 13.0F, 13.0F, new Dilation(-0.002F))
		.uv(92, 80).cuboid(-7.0F, -1.0F, -10.0F, 14.0F, 2.0F, 4.0F, new Dilation(0.0F))
		.uv(92, 86).cuboid(-8.0F, -1.0F, 7.0F, 16.0F, 2.0F, 1.0F, new Dilation(0.0F))
		.uv(80, 105).cuboid(-8.0F, -1.0F, -8.0F, 1.0F, 2.0F, 16.0F, new Dilation(0.0F))
		.uv(92, 62).cuboid(7.0F, -1.0F, -8.0F, 1.0F, 2.0F, 16.0F, new Dilation(0.0F))
		.uv(37, 88).cuboid(-7.0F, 1.0F, -7.0F, 14.0F, 2.0F, 15.0F, new Dilation(0.0F))
		.uv(38, 105).cuboid(-4.0F, 3.0F, -5.0F, 8.0F, 1.0F, 13.0F, new Dilation(0.002F))
		.uv(106, 97).cuboid(-5.0F, -1.0F, -1.0F, 2.0F, 2.0F, 5.0F, new Dilation(0.0F))
		.uv(112, 69).cuboid(3.0F, -1.0F, -1.0F, 2.0F, 2.0F, 5.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 20.0F, 0.0F));

		ModelPartData siegeA_r1 = submarine.addChild("siegeA_r1", ModelPartBuilder.create().uv(106, 111).cuboid(-4.0F, -5.0F, 0.0F, 8.0F, 5.0F, 2.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 1.0F, 4.0F, -0.1745F, 0.0F, 0.0F));

		ModelPartData tableaudebord_r1 = submarine.addChild("tableaudebord_r1", ModelPartBuilder.create().uv(44, 125).cuboid(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 2.0F, new Dilation(-0.002F)), ModelTransform.of(0.0F, 1.0F, -5.0F, -0.7854F, 0.0F, 0.0F));

		ModelPartData volant_r1 = submarine.addChild("volant_r1", ModelPartBuilder.create().uv(92, 89).cuboid(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 3.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 0.0F, -4.0F, -0.7854F, 0.0F, 0.0F));

		ModelPartData propulseA = submarine.addChild("propulseA", ModelPartBuilder.create().uv(92, 97).cuboid(-2.0F, -2.0F, -1.0F, 3.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(-3.0F, 2.0F, 9.0F));

		ModelPartData propulseur = submarine.addChild("propulseur", ModelPartBuilder.create().uv(92, 93).cuboid(-1.0F, -2.0F, -1.0F, 3.0F, 3.0F, 1.0F, new Dilation(0.0F)), ModelTransform.pivot(3.0F, 2.0F, 9.0F));

		ModelPartData float = modelPartData.addChild("float", ModelPartBuilder.create().uv(20, 50).cuboid(-4.0F, -2.0F, 2.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(20, 34).cuboid(-4.0F, -2.0F, 3.0F, 8.0F, 2.0F, 2.0F, new Dilation(0.01F))
		.uv(20, 46).cuboid(2.0F, -2.0F, 2.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(0, 34).cuboid(3.0F, -2.0F, -4.0F, 2.0F, 2.0F, 8.0F, new Dilation(0.0F))
		.uv(20, 42).cuboid(2.0F, -2.0F, -4.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(0, 44).cuboid(-5.0F, -2.0F, -4.0F, 2.0F, 2.0F, 8.0F, new Dilation(0.0F))
		.uv(20, 38).cuboid(-4.0F, -2.0F, -4.0F, 2.0F, 2.0F, 2.0F, new Dilation(-0.002F))
		.uv(0, 54).cuboid(-4.0F, -2.0F, -5.0F, 8.0F, 2.0F, 2.0F, new Dilation(0.02F)), ModelTransform.pivot(0.0F, 24.0F, 0.0F));
		return TexturedModelData.of(modelData, 128, 128);
	}
	@Override
	public void setAngles(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}
	@Override
	public void render(MatrixStack matrices, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha) {
		kfp.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		jetpack.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		submarine.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
		float.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
	}
}